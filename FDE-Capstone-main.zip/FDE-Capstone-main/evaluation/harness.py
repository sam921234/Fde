#!/usr/bin/env python3
"""The unattended evaluation run.

    python -m evaluation.harness --input data/validation_tickets.json \
                                 --output evaluation/results/

This is the component the project is gated on (A9, A10), so it is written with
one assumption: it will be pointed at a file nobody here has seen, on a machine
nobody here owns, and nobody will be watching it.

That assumption produces the rules this module follows:

  - the input and output paths are arguments, never constants
  - every ticket produces a row, including the ones that fail; a ticket that
    raises is recorded as an escalation with the error attached rather than
    skipped, because a silently dropped ticket is worse than a failed one
  - nothing waits for input, and nothing needs a key; with no provider
    configured the pipeline uses its extractive generator and the run completes
  - the metrics report is written by this code, not calculated afterwards
  - partial results are flushed as the run proceeds, so an interrupted run
    still leaves evidence of how far it got

Exit codes: 0 if the run completed, 1 if it could not start, 2 if it completed
but the decision log did not reconcile. The last one exists so that CI notices
a reconciliation gap rather than a human having to spot it.
"""

from __future__ import annotations

import argparse
import json
import logging
import platform
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from evaluation.metrics import (  # noqa: E402
    business_metrics,
    calibration_table,
    classification_metrics,
    fairness_segments,
    governance_metrics,
    latency_metrics,
    retrieval_metrics,
    volume_metrics,
)
from src import __version__  # noqa: E402
from src.config import settings  # noqa: E402
from src.ingest import load_tickets  # noqa: E402
from src.logging_store import DecisionLog  # noqa: E402
from src.pipeline import Pipeline  # noqa: E402
from src.schema import Response, Ticket  # noqa: E402

log = logging.getLogger("harness")


def build_row(ticket: Ticket, response: Response, retriever_docs: set[str]) -> dict[str, Any]:
    """One flat record per ticket: what came in, what the system did, and the
    label if the file carried one. The metrics functions read only this."""
    labels = ticket.labels or {}
    cited = [c["doc_id"] for c in response.citations]
    retrieved = [p.doc_id for p in response.passages]
    return {
        "ticket_id": ticket.ticket_id,
        "channel": ticket.channel,
        "customer_tier": ticket.customer_tier,
        "customer_region": ticket.customer_region,
        "language_fluency": ticket.language_fluency,
        "body_length": len(ticket.body),
        "action": response.action,
        "predicted_intent": response.classification.intent if response.classification else "",
        "confidence": response.classification.intent_confidence if response.classification else 0.0,
        "predicted_urgency": response.classification.urgency if response.classification else "",
        "routing_rule": response.routing.rule if response.routing else "",
        "routing_reason": response.routing.reason if response.routing else "",
        "retrieved_doc_ids": retrieved,
        "cited_doc_ids": cited,
        # A6 is checked by following the citation, so the harness checks it too
        # rather than trusting the pipeline to have done so.
        "citations_resolve": all(d in retriever_docs for d in cited),
        "guardrails_failed": [g.name for g in response.guardrails if not g.passed],
        "guardrails_blocked": response.blocked_by,
        "latency_seconds": response.latency_seconds,
        "generation_method": response.generation_method,
        "response_chars": len(response.body),
        "error": response.error,
        # labels, present only when the input file carries them
        "true_intent": labels.get("intent"),
        "true_urgency": labels.get("urgency"),
        "expected_route": labels.get("expected_route"),
        "expected_doc_ids": labels.get("expected_doc_ids"),
        "answerable_from_docs": labels.get("answerable_from_docs"),
        "must_not_auto_respond": labels.get("must_not_auto_respond"),
    }


def run(
    input_path: Path,
    output_dir: Path,
    *,
    limit: int | None = None,
    run_id: str | None = None,
    threshold: float | None = None,
    progress_every: int = 10,
) -> tuple[dict[str, Any], int]:
    started_wall = datetime.now(timezone.utc)
    started = time.perf_counter()
    run_id = run_id or f"run-{started_wall.strftime('%Y%m%dT%H%M%SZ')}-{uuid.uuid4().hex[:6]}"
    output_dir.mkdir(parents=True, exist_ok=True)

    tickets = load_tickets(input_path)
    if limit:
        tickets = tickets[:limit]
    log.info("loaded %d tickets from %s", len(tickets), input_path)

    decision_log = DecisionLog(output_dir / "decisions.db", run_id=run_id)
    pipeline = Pipeline(decision_log=decision_log, threshold=threshold)
    retriever_docs = set(pipeline.retriever.documents)

    rows: list[dict[str, Any]] = []
    responses_path = output_dir / "responses.jsonl"
    failures = 0

    with responses_path.open("w", encoding="utf-8") as handle:
        for index, ticket in enumerate(tickets, start=1):
            try:
                response = pipeline.process(ticket)
            except Exception as exc:  # noqa: BLE001
                # Pipeline.process already catches everything; this is the
                # belt-and-braces layer. If it ever fires, the run continues.
                failures += 1
                log.error("ticket %s could not be processed: %s", ticket.ticket_id, exc)
                response = Response(
                    ticket_id=ticket.ticket_id,
                    action="escalate",
                    body="",
                    escalation_note="Harness-level failure; this ticket needs a human.",
                    error=f"{type(exc).__name__}: {exc}",
                )
            row = build_row(ticket, response, retriever_docs)
            rows.append(row)
            handle.write(
                json.dumps(
                    {**row, "response_body": response.body, "escalation_note": response.escalation_note}
                )
                + "\n"
            )
            handle.flush()  # so an interrupted run still leaves usable evidence
            if progress_every and index % progress_every == 0:
                elapsed = time.perf_counter() - started
                log.info(
                    "%d/%d processed (%.1f tickets/sec)", index, len(tickets), index / max(elapsed, 1e-6)
                )

    duration = time.perf_counter() - started
    reconciliation = decision_log.reconcile(len(rows), run_id=run_id)
    decision_log.export_jsonl(output_dir / "decision_log.jsonl", run_id=run_id)

    report = {
        "run": {
            "run_id": run_id,
            "started_at": started_wall.isoformat(timespec="seconds").replace("+00:00", "Z"),
            "finished_at": datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z"),
            "duration_seconds": round(duration, 2),
            "tickets_per_second": round(len(rows) / duration, 2) if duration else 0.0,
            "input_path": str(input_path),
            "output_dir": str(output_dir),
            "system_version": __version__,
            "python": platform.python_version(),
            "platform": platform.platform(),
            "model_provider": pipeline.provider.name,
            "provider_available": pipeline.provider.available,
            "provider_model": pipeline.provider.version,
            "retrieval": pipeline.retriever.stats,
            "confidence_threshold": pipeline.threshold,
            "high_cost_threshold": settings.high_cost_threshold,
            "harness_level_failures": failures,
            "unattended": True,
        },
        "volume": volume_metrics(rows),
        "business": business_metrics(rows),
        "technical": {
            "classification": classification_metrics(rows),
            "retrieval": retrieval_metrics(rows),
            "latency": latency_metrics(rows),
            "calibration": calibration_table(rows),
        },
        "governance": governance_metrics(rows, reconciliation),
        "fairness": fairness_segments(rows),
    }

    (output_dir / "metrics.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (output_dir / "summary.md").write_text(render_summary(report), encoding="utf-8")
    decision_log.close()

    exit_code = 0 if reconciliation["reconciles"] else 2
    return report, exit_code


# The targets in the summary table are the ones in section 8 of
# submission/03_Workbooks/Stage_2_PRD_v2.0.md, with the two technical ones from
# section 5. They were wrong here for a while: the table claimed 60% first
# contact resolution against a target of 65%, 30% escalation against 35%, five
# minutes to first reply against one, and three seconds at the 95th percentile
# against a budget written as ten on chat and sixty elsewhere. A generated
# report that restates the requirement incorrectly is worse than one that omits
# it, because it is the artefact somebody checks the requirement against.
def _rate(value: float, basis: int) -> str:
    """A percentage and what it was taken over, or a note that it was over nothing.

    A rate with a denominator of zero is not zero per cent, and printing it as
    0.0% is how a run over an unlabelled file reads as a failing one.
    """
    if not basis:
        return NOT_SCORED
    return f"{value:.1%} (n={basis})"


TARGETS = {
    "first_contact_resolution": "65%",
    "escalation_rate": "35%",
    "automated_reply": "under 1 min",
    "weighted_precision": "85%",
    "retrieval_recall": "90%",
    "citation_accuracy": "95%",
    "latency_p95": "10 s chat, 60 s other",
    "calibration_band_gap": "5 pts",
}

NOT_SCORED = "not scored: the input file carried no labels"


def render_summary(report: dict[str, Any]) -> str:
    """A readable version of metrics.json.

    This exists because a support manager is not going to open a JSON file, and
    because the figures I quote in the report should come from the same place
    the system wrote them.
    """
    run = report["run"]
    volume = report["volume"]
    business = report["business"]
    classification = report["technical"]["classification"]
    retrieval = report["technical"]["retrieval"]
    latency = report["technical"]["latency"]
    calibration = report["technical"]["calibration"]
    governance = report["governance"]

    # A file with no labels is a normal thing to point the harness at: it is how
    # a real queue arrives. Rendering the unscorable measures as 0.0% read as a
    # system that got everything wrong, which is a worse lie than saying nothing.
    scored = "note" not in classification
    _accuracy = f"{classification['accuracy']:.1%}" if scored else NOT_SCORED
    _weighted_precision = f"{classification['weighted_precision']:.1%}" if scored else NOT_SCORED
    _macro_precision = f"{classification['macro_precision']:.1%}" if scored else NOT_SCORED
    _ece = f"{calibration['expected_calibration_error']:.4f}" if calibration["bands"] else NOT_SCORED
    _band_gap = (
        f"{calibration['worst_band_gap_points']:.1f} pts (over {calibration['bands_counted']} bands "
        f"holding {calibration['predictions_in_counted_bands']} predictions)"
        if calibration["bands"]
        else NOT_SCORED
    )
    _verified_all = _rate(
        business["verified_fcr_over_all_labelled_auto_answers"],
        business["verified_fcr_over_all_labelled_auto_answers_basis"],
    )
    _verified_answerable = _rate(
        business["verified_fcr_over_answerable_auto_answers_only"],
        business["verified_fcr_over_answerable_auto_answers_only_basis"],
    )
    _citation_all = _rate(
        retrieval["citation_accuracy_over_all_labelled_replies"],
        retrieval["citation_accuracy_over_all_labelled_replies_basis"],
    )
    _citation_answerable = _rate(
        retrieval["citation_accuracy_over_answerable_replies_only"],
        retrieval["citation_accuracy_over_answerable_replies_only_basis"],
    )
    _routing_agreement = _rate(business["routing_agreement_with_labels"], business["routing_agreement_basis"])

    lines = [
        f"# Evaluation run {run['run_id']}",
        "",
        f"Input: `{run['input_path']}`  ",
        f"Started: {run['started_at']}  ",
        f"Duration: {run['duration_seconds']}s ({run['tickets_per_second']} tickets/sec)  ",
        f"Provider: {run['model_provider']} (available: {run['provider_available']})  ",
        f"Retrieval: {run['retrieval']['backend']}, top_k={run['retrieval']['top_k']}, "
        f"floor={run['retrieval']['floor']}  ",
        f"Confidence threshold: {run['confidence_threshold']}",
        "",
        "## Volume",
        "",
        "| Measure | Value |",
        "| --- | --- |",
        f"| Tickets processed | {volume['tickets_processed']} |",
        f"| Answered automatically | {volume['answered_automatically']} |",
        f"| Escalated | {volume['escalated']} |",
        f"| Blocked by a guardrail | {volume['blocked_by_guardrails']} |",
        f"| Processing errors | {volume['processing_errors']} |",
        "",
        "## Business outcomes",
        "",
        "| Measure | Baseline | Target | This run |",
        "| --- | --- | --- | --- |",
        f"| First contact resolution | {business['baseline_first_contact_resolution']:.1%} | "
        f"{TARGETS['first_contact_resolution']} | {business['first_contact_resolution']:.1%} |",
        f"| Verified resolution, every labelled automatic answer | - | - | " f"{_verified_all} |",
        f"| Verified resolution, answerable tickets only | - | - | {_verified_answerable} |",
        f"| Escalation rate | {business['baseline_escalation_rate']:.1%} | "
        f"{TARGETS['escalation_rate']} | {business['escalation_rate']:.1%} |",
        f"| Median reply, automated | {business['baseline_median_reply_minutes']:.0f} min | "
        f"{TARGETS['automated_reply']} | {business['automated_reply_seconds_median']:.3f} s |",
        f"| Median reply, blended | {business['baseline_median_reply_minutes']:.0f} min | - | "
        f"{business['blended_reply_minutes_median']:.1f} min |",
        f"| Routing agreement with labels | - | - | {_routing_agreement} |",
        "",
        "The two verified figures differ only in what they divide by. The first counts every "
        "automatic answer the input file carries a coverage label for, including the "
        f"{business['auto_answers_on_tickets_the_corpus_does_not_cover']} answered on tickets no "
        "article covers, which can never cite a document the labels agree with. The second leaves "
        "those out and measures retrieval and citation alone. The first is the one to quote.",
        "",
        f"Blended figure assumption: {business['blended_reply_assumption']}.",
        "",
        "## Technical",
        "",
        "| Measure | Target | This run |",
        "| --- | --- | --- |",
        f"| Intent accuracy | - | {_accuracy} |",
        f"| Weighted precision | {TARGETS['weighted_precision']} | {_weighted_precision} |",
        f"| Macro precision | - | {_macro_precision} |",
        f"| Retrieval recall@k | {TARGETS['retrieval_recall']} | {retrieval['recall_at_k']:.1%} |",
        f"| Citation accuracy, every labelled reply | {TARGETS['citation_accuracy']} | " f"{_citation_all} |",
        f"| Citation accuracy, answerable tickets only | {TARGETS['citation_accuracy']} | "
        f"{_citation_answerable} |",
        f"| Latency p95 | {TARGETS['latency_p95']} | {latency['p95_seconds']:.3f} s |",
        f"| Calibration error (ECE) | - | {_ece} |",
        f"| Calibration, worst band gap | {TARGETS['calibration_band_gap']} | {_band_gap} |",
        "",
        "## Governance",
        "",
        "| Condition | Requirement | This run |",
        "| --- | --- | --- |",
        f"| Decisions logged | complete | {governance['decisions_logged']} across "
        f"{governance['tickets_with_decisions']} tickets |",
        f"| Log reconciles with tickets | must match | "
        f"{'yes' if governance['decision_log_reconciles'] else 'NO'} |",
        f"| Private data in outbound text | zero | {governance['private_data_detections']} |",
        f"| Never-auto-respond breaches | zero | {governance['must_not_auto_respond_breaches']} of "
        f"{governance['must_not_auto_respond_tickets']} |",
        f"| Injection attempts detected | - | {governance['injection_attempts_detected']} |",
        "",
        "Responses blocked before sending: "
        + (
            ", ".join(f"{k} {v}" for k, v in sorted(governance["guardrail_blocks"].items()))
            or (
                f"none. All {governance['responses_released']} released responses passed every "
                "check, because routing had already diverted the rest. On this data the guardrails "
                "are the second line rather than the one doing the work, and the evidence that they "
                "block is the test suite, not this run."
            )
        ),
        "",
        "## Fairness",
        "",
        "| Dimension | Spread in verified resolution | Under 5 points |",
        "| --- | --- | --- |",
    ]
    for name, block in report["fairness"].items():
        spread = block["verified_resolution_spread_points"]
        spread_text = f"{spread:.1f} pts" if spread is not None else "not comparable"
        lines.append(f"| {name} | {spread_text} | {'yes' if block['within_five_points'] else 'no'} |")

    thin = calibration["predictions_in_thin_bands"]
    if thin:
        lines += [
            "",
            f"Calibration bands holding fewer than {calibration['minimum_band_size_counted']} "
            f"predictions are excluded from the worst-gap figure; {thin} prediction(s) fall in "
            f"those bands. Across every band including them the worst gap is "
            f"{calibration['worst_band_gap_all_bands']:.1f} points, which is one or two tickets "
            "rather than a calibration problem. The expected calibration error above is over all "
            "bands and is the figure to read.",
        ]

    lines += [
        "",
        "Segments with fewer than ten labelled automatic answers are excluded from the spread, "
        "because one ticket moves them by more than the threshold being tested.",
        "",
        f"Generated by evaluation/harness.py, system version {run['system_version']}.",
    ]
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Process a ticket file end to end and write a metrics report."
    )
    parser.add_argument("--input", required=True, help="path to a ticket file in the standard schema")
    parser.add_argument("--output", required=True, help="directory to write results into")
    parser.add_argument("--limit", type=int, default=None, help="process only the first N tickets")
    parser.add_argument("--run-id", default=None)
    parser.add_argument("--threshold", type=float, default=None, help="override the confidence threshold")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.WARNING if args.quiet else getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)-7s %(name)s %(message)s",
    )

    input_path = Path(args.input)
    if not input_path.exists():
        log.error("input file does not exist: %s", input_path)
        return 1

    try:
        report, exit_code = run(
            input_path,
            Path(args.output),
            limit=args.limit,
            run_id=args.run_id,
            threshold=args.threshold,
            progress_every=0 if args.quiet else 10,
        )
    except Exception as exc:  # noqa: BLE001
        log.exception("the run could not start: %s", exc)
        return 1

    if not args.quiet:
        print()
        print(render_summary(report))
    if exit_code == 2:
        log.error(
            "decision log did not reconcile: %d tickets, %d with decisions",
            report["volume"]["tickets_processed"],
            report["governance"]["tickets_with_decisions"],
        )
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
