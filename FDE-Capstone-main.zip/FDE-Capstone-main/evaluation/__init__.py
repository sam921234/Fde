"""Evaluation harness and metrics."""
